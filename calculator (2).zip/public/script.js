// Calculator logic
let currentResult = "";
let history = [];

function appendNumber(number) {
    currentResult += number;
    updateResult();
}

function appendOperator(operator) {
    currentResult += operator;
    updateResult();
}

function clearResult() {
    currentResult = "";
    updateResult();
}

function calculateResult() {
    const result = eval(currentResult);
    saveResult(result);
    clearResult();
}

function updateResult() {
    document.getElementById("result").value = currentResult;
}

// History logic
function saveResult(result) {
    fetch('/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ result })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            history.unshift(result);
            updateHistory();
        }
    });
}

function updateHistory() {
    const historyList = document.getElementById("historyList");
    historyList.innerHTML = "";

    history.forEach(result => {
        const li = document.createElement("li");
        li.innerText = result;
        historyList.appendChild(li);
    });
}
