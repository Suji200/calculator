const express = require('express');
const mongoose = require('mongoose');
const Calculator = require('./calculator'); 



const app = express();
const port = 3001;

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/calculator', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error);
  });

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});



app.use(express.json());
app.use(express.static('public')); 

app.get('/', (req, res) => {
  Calculator.find()
    .sort({ timestamp: -1 })
    .then(() => {
      res.sendFile('index.html');
    })
    .catch((error) => {
      res.status(500).json({ error: 'Failed to fetch calculations' });
    });
});

app.post('/', (req, res) => {
  const {  operand1, operand2, operator, result } = req.body;

  const newCalculation = new Calculator({    
    operand1: operand1,
    operand2: operand2,
    operator: operator,
    result: result
  });

  newCalculation.save()
    .then(() => {
      res.status(201).json({ message: 'Calculation saved successfully' });
    })
    .catch((error) => {
      res.status(500).json(error);
    });
});