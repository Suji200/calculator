const mongoose = require('mongoose');

const calculatorSchema = new mongoose.Schema({
  
  operand1: {
    type: String,
    required: true,
  },
  operand2: {
    type: String,
    required: true,
  },
  operator: {
    type: String,
    required: true,
  },
  result: {
    type: String,
    required: true,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  timestamp1: {
    type: Date,
    default: Date.now,
  },
});

const Calculator = mongoose.model('Calculator', calculatorSchema);

module.exports = Calculator;


// operand1: {
//   type: String,
//   required: true,
// },
// operand2: {
//   type: String,
//   required: true,
// },
// operation: {
//   type: String,
//   required: true,
// },